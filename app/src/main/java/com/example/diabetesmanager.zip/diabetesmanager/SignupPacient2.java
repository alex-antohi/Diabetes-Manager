package com.example.diabetesmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class SignupPacient2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_pacient2);
    }

    public void next2(View view) {
        Intent intent = new Intent(this, SignupDoctor3.class);
        startActivity(intent);
    }
}